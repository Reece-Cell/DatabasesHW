package heapdb.query;


import heapdb.ITable;
import heapdb.Schema;
import heapdb.Table;
import heapdb.Tuple;

/**
 * A simple select query of the form:
 * select column, column, . . . from table where condition
 * 
 * @author Glenn
 *
 */

public class SelectQuery  {
	
	private Condition cond;
	private String[] colNames;	   // a value of null means return all columns of the table
	
	/**
	 * A query that contains both a where condition and a projection of columns
	 * @param colNames are the columns to return
	 * @param cond is the where clause
	 */
	public SelectQuery(String[] colNames, Condition cond) {
		this.colNames = colNames;
		this.cond = cond;
	}
	
	/**
	 * A query that contains both a where condition.  All columns 
	 * of the Tuples are returned.
	 * @param cond is the where clause
	 */
	public SelectQuery(Condition cond) {
		this(null, cond);
	}
	
	
	public static Table naturalJoin(ITable table1, ITable table2) {
		// TODO replace with your code.
		Schema joinedSchema = table1.getSchema().naturaljoin(table2.getSchema());
		throw new  UnsupportedOperationException();
	}
	
	public ITable eval(ITable table) {
		Schema evaluated;
		if(this.colNames == null){
			evaluated = table.getSchema();
		}else{
			evaluated = table.getSchema().project(colNames);
		}
		Table evaltable = new Table(evaluated);
		for(Tuple i: table){
			if(cond!=null && cond.eval(i)){
				if(colNames==null){
					evaltable.insert(i);
				}else{
					evaltable.insert(i.project(evaluated));
				}
			}

		}
		return evaltable;
	}

	@Override
	public String toString() {
	    String proj_columns;
	    if (colNames != null) {
	    	proj_columns = String.join(",", colNames);
	    } else {
	    	proj_columns = "*";
	    }
	    return "select " + proj_columns + " where " + cond;
	}

}
